# ISC Certifications Hands-On lab kit

Start with lessons/CLB-001_Check_the_Training_Setup_Before_Creating_a_Campaign.md, then CLB-002 for the CSV setup and CLB-003 for the first review.

Keep this folder structure. Run the collector commands from this course folder. The lessons name their starting data, required actors, expected checks and reset.

CSV files contain synthetic values. Prepare complete private working copies using the actual source templates and approved test email addresses before import. Keep those copies and captured tenant evidence in private/, separate from the reusable files.

The lab-data folders contain starting values and expected comparisons. Expected-value files are not tenant observations. For the independent CLB-017 project, derive the required result from its work request.

The author/contracts folder contains the read-only request plan and blank collector configuration; author/tests contains the offline collector checks. Worked assessor answers are not included.
